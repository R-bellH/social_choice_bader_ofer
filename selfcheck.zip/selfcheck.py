import json
from Election import Election
from Apportionment import bader_ofer, largest_remainders


# Function to read profiles from a file
def read_profiles_from_file(filename):
    loaded_elections = []
    with open(filename, "r") as file:
        for line in file:
            data = json.loads(line)
            loaded_election = Election(**data)
            loaded_elections.append(loaded_election)
    return loaded_elections


def main():
    # Read profiles from file
    loaded_profiles = read_profiles_from_file('hw3.in')

    with open('hw3_bader_ofer.out', 'w') as out_file:
        for loaded_profile in loaded_profiles:
            predictions = bader_ofer(loaded_profile)
            out_file.write(f"Results for Profile {loaded_profiles.index(loaded_profile) + 1}:\n")
            out_file.write(f"bader_ofer_predictions:{predictions}\n")
            out_file.write(f"\n")

    with open('hw3_largest_reminders.out', 'w') as out_file:
        for loaded_profile in loaded_profiles:
            predictions = largest_remainders(loaded_profile)
            out_file.write(f"Results for Profile {loaded_profiles.index(loaded_profile) + 1}:\n")
            out_file.write(f"largest_remainders_predictions:{predictions}\n")
            out_file.write(f"\n")


if __name__ == "__main__":
    main()
